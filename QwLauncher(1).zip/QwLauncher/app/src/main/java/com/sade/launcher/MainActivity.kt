package com.sade.launcher

import android.app.Activity
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

data class App(val label: String, val component: ComponentName, val glyph: Int) {
    val key: String get() = component.flattenToString()
}

private class BarEntry(val label: String, val glyph: Int, val open: () -> Unit)
private enum class Src { DRAWER, HOME, BAR }
private class DragInfo(val key: String, val src: Src, val anchor: View)

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var audio: AudioManager
    private var apps: List<App> = emptyList()

    private lateinit var root: FrameLayout
    private lateinit var homeLayer: FrameLayout
    private lateinit var homeCol: LinearLayout
    private lateinit var clockCard: BlurPanel
    private lateinit var favPanel: BlurPanel
    private lateinit var favGrid: GridLayout
    private lateinit var drawer: FrameLayout
    private lateinit var drawerContent: LinearLayout
    private lateinit var drawerGrid: GridView
    private lateinit var searchEdit: EditText
    private lateinit var taskbar: BlurPanel
    private lateinit var barRow: LinearLayout
    private lateinit var panelLayer: FrameLayout
    private lateinit var sheet: BlurPanel
    private lateinit var notifScroll: ScrollView
    private lateinit var notifList: LinearLayout
    private lateinit var volumeBox: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var clearBtn: TextView
    private lateinit var dragCatcher: View

    private val adapter = AppAdapter()
    private val seekList = ArrayList<Pair<SeekBar, Int>>()
    private var drawerOpen = false
    private var panelOpen = false
    private var panelMode = 0 // 0 = bildirim, 1 = ses
    private var insetTop = 0
    private var insetBottom = 0
    private var drag: DragInfo? = null
    private val barH = 60
    private val maxBar = 5

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("sade", MODE_PRIVATE)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        window.setBackgroundDrawable(WaveBackground())
        window.setDecorFitsSystemWindows(false)
        buildUi()
        setContentView(root)
        loadApps()
        NotifService.onChange = { runOnUiThread { if (panelOpen && panelMode == 0) refreshNotifs() } }
    }

    override fun onDestroy() {
        super.onDestroy()
        NotifService.onChange = null
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (panelOpen) closePanel()
        if (drawerOpen) closeDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panelOpen) closePanel() else if (drawerOpen) closeDrawer()
    }

    // ================================================================== UI

    private fun buildUi() {
        root = FrameLayout(this)
        buildHome()
        buildDrawer()
        buildPanel()
        buildTaskbar()

        dragCatcher = View(this)
        dragCatcher.setOnDragListener { _, e ->
            when (e.action) {
                DragEvent.ACTION_DROP -> handleDrop(e.x, e.y)
                DragEvent.ACTION_DRAG_ENDED -> drag = null
            }
            true
        }
        root.addView(dragCatcher, FrameLayout.LayoutParams(MATCH, MATCH))

        // yukarı kaydır = çekmece, aşağı kaydır = bildirim paneli
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (drawerOpen || panelOpen) return false
                if (vy < -800f) { openDrawer(); return true }
                if (vy > 800f) { openPanel(0); return true }
                return false
            }
        })
        root.setOnTouchListener { _, e -> gd.onTouchEvent(e) }

        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            insetTop = b.top
            insetBottom = b.bottom
            applyInsets()
            ins
        }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> placeClock() }
    }

    private fun applyInsets() {
        val bottomSpace = insetBottom + dp(barH + 12 + 16)
        homeCol.setPadding(dp(16), insetTop + dp(16), dp(16), bottomSpace)
        drawerContent.setPadding(dp(16), insetTop + dp(16), dp(16), 0)
        drawerGrid.setPadding(0, 0, 0, bottomSpace)
        (sheet.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop + dp(12)
        sheet.requestLayout()
        (taskbar.layoutParams as FrameLayout.LayoutParams).bottomMargin = insetBottom + dp(12)
        taskbar.requestLayout()
        placeClock()
    }

    // ---------------------------------------------------------------- ana ekran

    private fun buildHome() {
        homeLayer = FrameLayout(this)
        homeCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        homeCol.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))

        favGrid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(6), dp(10), dp(6), dp(10))
        }
        favPanel = BlurPanel(this, 28f).apply {
            addView(favGrid, FrameLayout.LayoutParams(MATCH, WRAP))
            visibility = View.GONE
        }
        homeCol.addView(favPanel, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        val searchPanel = BlurPanel(this, 26f).apply {
            isClickable = true
            setOnClickListener { openDrawer(true) }
        }
        val sRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
        }
        sRow.addView(icon(R.drawable.ic_search, 20, SOFT))
        sRow.addView(TextView(this).apply {
            text = "Ara"; textSize = 15f; setTextColor(SOFT)
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(12) })
        searchPanel.addView(sRow, FrameLayout.LayoutParams(MATCH, MATCH))
        homeCol.addView(searchPanel, LinearLayout.LayoutParams(MATCH, dp(54)))
        homeLayer.addView(homeCol, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---- sürüklenebilir saat kartı (blur üzerinde)
        val clock = TextClock(this).apply {
            format12Hour = "HH:mm"; format24Hour = "HH:mm"
            textSize = 56f
            setTextColor(INK)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            includeFontPadding = false
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 14f
            setTextColor(SOFT)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(clock)
        col.addView(date)
        clockCard = BlurPanel(this, 28f).apply { addView(col, FrameLayout.LayoutParams(WRAP, WRAP)) }
        homeLayer.addView(clockCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START))

        var dX = 0f
        var dY = 0f
        clockCard.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = v.x - e.rawX
                    dY = v.y - e.rawY
                    v.parent.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    v.x = (e.rawX + dX).coerceIn(0f, (root.width - v.width).toFloat().coerceAtLeast(0f))
                    v.y = (e.rawY + dY).coerceIn(0f, (root.height - v.height).toFloat().coerceAtLeast(0f))
                    clockCard.refresh()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    prefs.edit()
                        .putFloat("cx", v.x / root.width.coerceAtLeast(1))
                        .putFloat("cy", v.y / root.height.coerceAtLeast(1))
                        .apply()
                }
            }
            true
        }
        clockCard.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> placeClock() }

        root.addView(homeLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun placeClock() {
        val w = root.width
        val h = root.height
        if (w == 0 || h == 0 || clockCard.width == 0) return
        val fx = prefs.getFloat("cx", -1f)
        val fy = prefs.getFloat("cy", -1f)
        val x = if (fx < 0f) dp(16).toFloat() else fx * w
        val y = if (fy < 0f) (insetTop + dp(16)).toFloat() else fy * h
        clockCard.x = x.coerceIn(0f, (w - clockCard.width).toFloat().coerceAtLeast(0f))
        clockCard.y = y.coerceIn(0f, (h - clockCard.height).toFloat().coerceAtLeast(0f))
        clockCard.refresh()
    }

    // ---------------------------------------------------------------- çekmece

    private fun buildDrawer() {
        drawer = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            isClickable = true
            setBackgroundColor(Color.argb(120, 255, 255, 255))
        }
        drawerContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val dSearch = BlurPanel(this, 26f)
        val dRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
        }
        dRow.addView(icon(R.drawable.ic_search, 20, SOFT))
        searchEdit = EditText(this).apply {
            hint = "Uygulama ara"
            setHintTextColor(SOFT)
            setTextColor(INK)
            textSize = 16f
            background = null
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_DONE
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ ->
                adapter.items.firstOrNull()?.let { launch(it) }
                true
            }
        }
        dRow.addView(searchEdit, LinearLayout.LayoutParams(MATCH, MATCH).apply { marginStart = dp(12) })
        dSearch.addView(dRow, FrameLayout.LayoutParams(MATCH, MATCH))
        drawerContent.addView(dSearch, LinearLayout.LayoutParams(MATCH, dp(54)))

        drawerGrid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(14)
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, p, _ -> launch(this@MainActivity.adapter.items[p]) }
            setOnItemLongClickListener { _, v, p, _ ->
                startDrag(v, this@MainActivity.adapter.items[p].key, Src.DRAWER)
                true
            }
        }
        drawerContent.addView(drawerGrid, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(16) })
        drawer.addView(drawerContent, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun updateHomeBlur() {
        homeLayer.setRenderEffect(
            if (drawerOpen || panelOpen) RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.CLAMP) else null
        )
    }

    private fun toggleDrawer() { if (drawerOpen) closeDrawer() else openDrawer() }

    private fun openDrawer(focus: Boolean = false) {
        if (panelOpen) closePanel()
        if (!drawerOpen) {
            drawerOpen = true
            searchEdit.setText("")
            drawer.visibility = View.VISIBLE
            drawer.alpha = 0f
            drawer.animate().alpha(1f).setDuration(220).start()
            updateHomeBlur()
        }
        if (focus) {
            searchEdit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchEdit, 0)
        }
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchEdit.windowToken, 0)
        searchEdit.clearFocus()
        updateHomeBlur()
        drawer.animate().alpha(0f).setDuration(180).withEndAction {
            if (!drawerOpen) drawer.visibility = View.GONE
        }.start()
    }

    // ---------------------------------------------------------------- bildirim + ses paneli

    private fun buildPanel() {
        panelLayer = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            isClickable = true
            setBackgroundColor(Color.argb(60, 255, 255, 255))
            setOnClickListener { closePanel() }
        }
        sheet = BlurPanel(this, 30f, 60f).apply { isClickable = true }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panelTitle = TextView(this).apply {
            textSize = 18f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
        }
        clearBtn = TextView(this).apply {
            text = "Temizle"; textSize = 13f; setTextColor(SOFT)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { try { NotifService.instance?.cancelAllNotifications() } catch (_: Exception) {} }
        }
        head.addView(panelTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(clearBtn)
        head.addView(tbBtn(R.drawable.ic_bell) { showPanelMode(0) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        head.addView(tbBtn(R.drawable.ic_volume) { showPanelMode(1) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })

        val body = FrameLayout(this)
        notifList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        notifScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(notifList, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        body.addView(notifScroll, FrameLayout.LayoutParams(MATCH, MATCH))

        volumeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        addSlider("Medya", R.drawable.ic_music, AudioManager.STREAM_MUSIC)
        addSlider("Zil", R.drawable.ic_bell, AudioManager.STREAM_RING)
        addSlider("Alarm", R.drawable.ic_clock, AudioManager.STREAM_ALARM)
        body.addView(volumeBox, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))

        sheet.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        panelLayer.addView(sheet, FrameLayout.LayoutParams(
            MATCH, (resources.displayMetrics.heightPixels * 0.62f).toInt(), Gravity.TOP
        ).apply { marginStart = dp(12); marginEnd = dp(12) })
        root.addView(panelLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun addSlider(label: String, res: Int, stream: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        row.addView(icon(res, 22, INK))
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(SOFT) })
        val seek = SeekBar(this).apply {
            max = audio.getStreamMaxVolume(stream)
            progress = audio.getStreamVolume(stream)
            progressTintList = ColorStateList.valueOf(accent())
            thumbTintList = ColorStateList.valueOf(accent())
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(70, 30, 58, 95))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        try { audio.setStreamVolume(stream, p, 0) } catch (_: SecurityException) {}
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        c.addView(seek, LinearLayout.LayoutParams(MATCH, WRAP))
        seekList.add(seek to stream)
        row.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        volumeBox.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun togglePanel(mode: Int) {
        if (panelOpen && panelMode == mode) closePanel() else openPanel(mode)
    }

    private fun openPanel(mode: Int) {
        if (drawerOpen) closeDrawer()
        if (!panelOpen) {
            panelOpen = true
            panelLayer.visibility = View.VISIBLE
            panelLayer.alpha = 0f
            panelLayer.animate().alpha(1f).setDuration(220).start()
            updateHomeBlur()
        }
        showPanelMode(mode)
    }

    private fun closePanel() {
        if (!panelOpen) return
        panelOpen = false
        updateHomeBlur()
        panelLayer.animate().alpha(0f).setDuration(180).withEndAction {
            if (!panelOpen) panelLayer.visibility = View.GONE
        }.start()
    }

    private fun showPanelMode(mode: Int) {
        panelMode = mode
        panelTitle.text = if (mode == 0) "Bildirimler" else "Ses"
        notifScroll.visibility = if (mode == 0) View.VISIBLE else View.GONE
        volumeBox.visibility = if (mode == 1) View.VISIBLE else View.GONE
        clearBtn.visibility = if (mode == 0) View.VISIBLE else View.GONE
        if (mode == 0) refreshNotifs()
        else seekList.forEach { (s, st) -> s.progress = audio.getStreamVolume(st) }
    }

    private fun notifAccessEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        return s.contains(packageName)
    }

    private fun hintCard(text: String, btn: String?, action: (() -> Unit)?) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply { setColor(Color.argb(120, 255, 255, 255)); cornerRadius = dpf(18f) }
        }
        c.addView(TextView(this).apply { this.text = text; textSize = 14f; setTextColor(INK) })
        if (btn != null && action != null) {
            c.addView(TextView(this).apply {
                this.text = btn; textSize = 14f; setTextColor(accent()); typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(12), 0, 0)
                setOnClickListener { action() }
            })
        }
        notifList.addView(c, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun refreshNotifs() {
        notifList.removeAllViews()
        if (!notifAccessEnabled()) {
            hintCard("Bildirimleri burada göstermek için bildirim erişimi vermen gerekiyor.", "Erişimi aç") {
                tryStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            return
        }
        val list: List<StatusBarNotification> = try {
            (NotifService.instance?.activeNotifications ?: emptyArray())
                .filter { (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
                .sortedByDescending { it.postTime }
        } catch (e: Exception) { emptyList() }
        if (list.isEmpty()) {
            hintCard("Bildirim yok", null, null)
            return
        }
        for (sbn in list) {
            notifList.addView(notifItem(sbn), LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }
    }

    private fun notifItem(sbn: StatusBarNotification): View {
        val n = sbn.notification
        val pm = packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(6), dp(10))
            background = GradientDrawable().apply { setColor(Color.argb(120, 255, 255, 255)); cornerRadius = dpf(18f) }
            isClickable = true
            setOnClickListener {
                try { n.contentIntent?.send() } catch (_: Exception) {}
                if ((n.flags and Notification.FLAG_AUTO_CANCEL) != 0) {
                    try { NotifService.instance?.cancelNotification(sbn.key) } catch (_: Exception) {}
                }
                closePanel()
            }
        }
        val ic = ImageView(this).apply { setImageDrawable(appTile(glyphFor(sbn.packageName, label))) }
        row.addView(ic, LinearLayout.LayoutParams(dp(36), dp(36)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply { this.text = label; textSize = 11f; setTextColor(SOFT); maxLines = 1 })
        col.addView(TextView(this).apply {
            this.text = title; textSize = 14f; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        if (text.isNotBlank()) {
            col.addView(TextView(this).apply {
                this.text = text; textSize = 13f; setTextColor(INK)
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            })
        }
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12) })

        val x = icon(R.drawable.ic_x, 18, SOFT).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { try { NotifService.instance?.cancelNotification(sbn.key) } catch (_: Exception) {} }
        }
        row.addView(x, LinearLayout.LayoutParams(dp(34), dp(34)))
        return row
    }

    // ---------------------------------------------------------------- görev çubuğu

    private fun ripple() = RippleDrawable(
        ColorStateList.valueOf(Color.argb(50, 30, 58, 95)), null,
        GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dpf(12f) }
    )

    private fun tbBtn(res: Int, action: () -> Unit): FrameLayout = FrameLayout(this).apply {
        addView(icon(res, 22), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        foreground = ripple()
        isClickable = true
        setOnClickListener { action() }
    }

    private fun buildTaskbar() {
        taskbar = BlurPanel(this, 22f)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(tbBtn(R.drawable.ic_grid) { toggleDrawer() },
            LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(6) })
        barRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bar.addView(barRow, LinearLayout.LayoutParams(0, MATCH, 1f))
        bar.addView(tbBtn(R.drawable.ic_bell) { togglePanel(0) }, LinearLayout.LayoutParams(dp(34), dp(40)))
        bar.addView(tbBtn(R.drawable.ic_volume) { togglePanel(1) },
            LinearLayout.LayoutParams(dp(34), dp(40)).apply { marginEnd = dp(6) })
        taskbar.addView(bar, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(taskbar, FrameLayout.LayoutParams(MATCH, dp(barH), Gravity.BOTTOM).apply {
            marginStart = dp(16); marginEnd = dp(16)
        })
    }

    private val defaultBar = "sys:phone\nsys:message\nsys:camera\nsys:browser"

    private fun barKeys(): MutableList<String> =
        (prefs.getString("bar", defaultBar) ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun saveBar(l: List<String>) = prefs.edit().putString("bar", l.joinToString("\n")).apply()

    private fun entryFor(key: String): BarEntry? {
        if (key.startsWith("sys:")) {
            return when (key) {
                "sys:phone" -> BarEntry("Telefon", R.drawable.ic_phone) { tryStart(Intent(Intent.ACTION_DIAL)) }
                "sys:message" -> BarEntry("Mesajlar", R.drawable.ic_message) {
                    tryStart(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
                }
                "sys:camera" -> BarEntry("Kamera", R.drawable.ic_camera) {
                    tryStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                }
                "sys:browser" -> BarEntry("Tarayıcı", R.drawable.ic_globe) {
                    tryStart(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER))
                }
                else -> null
            }
        }
        val app = apps.find { it.key == key } ?: return null
        return BarEntry(app.label, app.glyph) { launch(app) }
    }

    private fun renderBar() {
        barRow.removeAllViews()
        for (key in barKeys()) {
            val e = entryFor(key) ?: continue
            barRow.addView(barCell(key, e), LinearLayout.LayoutParams(dp(40), MATCH))
        }
    }

    private fun barCell(key: String, e: BarEntry): FrameLayout = FrameLayout(this).apply {
        val iv = ImageView(context).apply { setImageDrawable(appTile(e.glyph)) }
        addView(iv, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        foreground = ripple()
        isClickable = true
        contentDescription = e.label
        setOnClickListener { e.open() }
        setOnLongClickListener { startDrag(this, key, Src.BAR); true }
    }

    private fun pinToBar(key: String, index: Int) {
        val l = barKeys()
        val old = l.indexOf(key)
        var idx = index
        if (old in 0 until idx) idx -= 1
        if (old >= 0) l.removeAt(old)
        else if (l.size >= maxBar) {
            Toast.makeText(this, "Görev çubuğu dolu (en fazla $maxBar)", Toast.LENGTH_SHORT).show()
            return
        }
        l.add(idx.coerceIn(0, l.size), key)
        saveBar(l)
        renderBar()
    }

    private fun unpin(key: String) {
        val l = barKeys()
        if (l.remove(key)) { saveBar(l); renderBar() }
    }

    // ---------------------------------------------------------------- sürükle-bırak

    private fun startDrag(v: View, key: String, src: Src) {
        drag = DragInfo(key, src, v)
        v.startDragAndDrop(ClipData.newPlainText("app", key), View.DragShadowBuilder(v), null, 0)
    }

    private fun rootRect(v: View): Rect {
        val a = IntArray(2)
        val r = IntArray(2)
        v.getLocationInWindow(a)
        root.getLocationInWindow(r)
        val l = a[0] - r[0]
        val t = a[1] - r[1]
        return Rect(l, t, l + v.width, t + v.height)
    }

    private fun indexFor(x: Float): Int {
        var idx = 0
        for (i in 0 until barRow.childCount) {
            val rc = rootRect(barRow.getChildAt(i))
            if (rc.exactCenterX() < x) idx = i + 1
        }
        return idx
    }

    private fun handleDrop(x: Float, y: Float) {
        val d = drag ?: return
        val a = rootRect(d.anchor).apply { inset(-dp(10), -dp(10)) }
        if (a.contains(x.toInt(), y.toInt())) {
            // yerinde bırakıldı = uzun basma menüsü
            showMenu(d.key, d.anchor)
            return
        }
        val inBar = x >= taskbar.left && x <= taskbar.right && y >= taskbar.top && y <= taskbar.bottom
        if (inBar) {
            pinToBar(d.key, indexFor(x))
            return
        }
        when (d.src) {
            Src.DRAWER -> { addFavorite(d.key); closeDrawer() }
            Src.BAR -> unpin(d.key)
            Src.HOME -> {}
        }
    }

    // ---------------------------------------------------------------- uygulamalar

    private fun loadApps() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(i, 0)
            .map {
                val label = it.loadLabel(pm).toString()
                val pkg = it.activityInfo.packageName
                App(label, ComponentName(pkg, it.activityInfo.name), glyphFor(pkg, label))
            }
            .filter { it.component.packageName != packageName }
            .sortedBy { it.label.lowercase() }
        applyFilter(searchEdit.text.toString())
        renderFavorites()
        renderBar()
    }

    private fun applyFilter(q: String) {
        adapter.items = if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private fun launch(app: App) {
        tryStart(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        closeDrawer()
    }

    private fun tryStart(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Uygulama bulunamadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun appCell(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(4), dp(2), dp(4))
        addView(ImageView(context), LinearLayout.LayoutParams(dp(52), dp(52)))
        addView(TextView(context).apply {
            textSize = 11f; setTextColor(INK); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
    }

    private fun bind(cell: LinearLayout, app: App) {
        (cell.getChildAt(0) as ImageView).setImageDrawable(appTile(app.glyph))
        (cell.getChildAt(1) as TextView).text = app.label
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<App> = emptyList()
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? LinearLayout) ?: appCell()
            bind(v, items[position])
            return v
        }
    }

    // ---------------------------------------------------------------- favoriler (ana ekran)

    private fun favKeys(): MutableList<String> =
        (prefs.getString("favs", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun saveFavs(l: List<String>) = prefs.edit().putString("favs", l.joinToString("\n")).apply()

    private fun addFavorite(key: String) {
        val l = favKeys()
        if (l.contains(key)) return
        if (l.size >= 8) {
            Toast.makeText(this, "Ana ekranda en fazla 8 uygulama", Toast.LENGTH_SHORT).show()
            return
        }
        l.add(key)
        saveFavs(l)
        renderFavorites()
    }

    private fun renderFavorites() {
        favGrid.removeAllViews()
        val list = favKeys().mapNotNull { k -> apps.find { it.key == k } }.take(8)
        favPanel.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (app in list) {
            val cell = appCell()
            bind(cell, app)
            cell.setOnClickListener { launch(app) }
            cell.setOnLongClickListener { startDrag(cell, app.key, Src.HOME); true }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setMargins(0, dp(6), 0, dp(6))
            favGrid.addView(cell, lp)
        }
    }

    private fun showMenu(key: String, anchor: View) {
        val app = apps.find { it.key == key }
        val inBar = barKeys().contains(key)
        val isFav = favKeys().contains(key)
        val pm = PopupMenu(this, anchor)
        if (app != null) pm.menu.add(0, 1, 0, if (isFav) "Ana ekrandan kaldır" else "Ana ekrana ekle")
        pm.menu.add(0, 2, 1, if (inBar) "Görev çubuğundan kaldır" else "Görev çubuğuna ekle")
        if (app != null) {
            pm.menu.add(0, 3, 2, "Uygulama bilgisi")
            pm.menu.add(0, 4, 3, "Kaldır")
        }
        pm.setOnMenuItemClickListener { item ->
            val pkg = Uri.parse("package:${app?.component?.packageName}")
            when (item.itemId) {
                1 -> {
                    val l = favKeys()
                    if (isFav) { l.remove(key); saveFavs(l); renderFavorites() } else addFavorite(key)
                }
                2 -> if (inBar) unpin(key) else pinToBar(key, Int.MAX_VALUE)
                3 -> tryStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
                4 -> tryStart(Intent(Intent.ACTION_DELETE, pkg))
            }
            true
        }
        pm.show()
    }
}
