package com.sade.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.view.ViewGroup
import android.widget.ImageView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

val INK = 0xFF1E3A5F.toInt()
val SOFT = 0xFF5B7A99.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Sistem (Material You) vurgu rengi, Android 12+. */
fun Context.accent(): Int = getColor(android.R.color.system_accent1_600)

/** Lucide ikonu (vector drawable) oluşturur ve istenen renge boyar. */
fun Context.icon(res: Int, sizeDp: Int, color: Int = INK): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        setColorFilter(color)
        layoutParams = ViewGroup.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

/** Yuvarlatılmış kare, accent arka plan, beyaz Lucide simgesi. */
class AppTile(private val glyph: Drawable, tileColor: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tileColor }

    override fun draw(c: Canvas) {
        val b = bounds
        val r = b.width() * 0.30f
        c.drawRoundRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), r, r, paint)
        val pad = (b.width() * 0.25f).toInt()
        glyph.setBounds(b.left + pad, b.top + pad, b.right - pad, b.bottom - pad)
        glyph.draw(c)
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun Context.appTile(glyphRes: Int): Drawable {
    val g = getDrawable(glyphRes)!!.mutate()
    g.setTint(Color.WHITE)
    return AppTile(g, accent())
}

/** Uygulamanın paket adı/adından uygun bir Lucide simgesi seçer. */
fun glyphFor(pkg: String, label: String): Int {
    val s = "$pkg $label".lowercase()
    fun has(vararg k: String) = k.any { s.contains(it) }
    return when {
        has("camera", "kamera") -> R.drawable.ic_camera
        has("gallery", "galeri", "photo", "foto") -> R.drawable.ic_image
        has("messag", "mms", "sms", "mesaj", "whatsapp", "telegram", "signal", "discord") -> R.drawable.ic_message
        has("dialer", "telecom", "phone", "telefon", "contacts", "rehber", "kişi") -> R.drawable.ic_phone
        has("chrome", "browser", "tarayıcı", "firefox", "opera", "brave", "edge") -> R.drawable.ic_globe
        has("music", "müzik", "spotify", "audio", "soundcloud") -> R.drawable.ic_music
        has("vending", "store", "market", "shop", "amazon", "trendyol", "hepsiburada") -> R.drawable.ic_bag
        has("youtube", "video", "netflix", "vlc") -> R.drawable.ic_play
        has("maps", "harita", "navigation") -> R.drawable.ic_map
        has("setting", "ayarlar") -> R.drawable.ic_settings
        has("clock", "saat", "alarm") -> R.drawable.ic_clock
        has("calendar", "takvim") -> R.drawable.ic_calendar
        has("mail", "gmail", "outlook") -> R.drawable.ic_mail
        has("files", "dosya", "documentsui", "drive") -> R.drawable.ic_folder
        has("calculator", "hesap") -> R.drawable.ic_calculator
        has("notes", "notlar", "keep", "docs", "office") -> R.drawable.ic_file
        has("game", "oyun", "bear", "minecraft", "roblox") -> R.drawable.ic_game
        else -> R.drawable.ic_box
    }
}
