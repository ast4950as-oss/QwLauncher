package com.sade.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout

/**
 * Arkasındaki dalga arka planın bulanık halini gösteren yuvarlak panel (Android 12+ RenderEffect).
 * İçerik eklerken panelin kendisine değil, içine koyduğun view'lara padding ver.
 * Panel hareket ettirildiyse refresh() çağır.
 */
class BlurPanel(ctx: Context, radiusDp: Float = 24f, blur: Float = 44f) : FrameLayout(ctx) {

    private val backdrop = Backdrop(ctx, blur)

    init {
        val d = resources.displayMetrics.density
        val r = radiusDp * d
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        clipToOutline = true

        addView(backdrop, LayoutParams(MATCH, MATCH))

        val tint = View(ctx)
        tint.background = GradientDrawable().apply {
            setColor(Color.argb(95, 255, 255, 255))
            setStroke(d.toInt().coerceAtLeast(1), Color.argb(150, 255, 255, 255))
            cornerRadius = r
        }
        addView(tint, LayoutParams(MATCH, MATCH))
    }

    fun refresh() { backdrop.invalidate() }

    private class Backdrop(ctx: Context, blur: Float) : View(ctx) {
        private val bg = WaveBackground()

        init {
            setRenderEffect(RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP))
        }

        override fun onDraw(canvas: Canvas) {
            var x = 0f
            var y = 0f
            var v: View = this
            while (true) {
                x += v.left + v.translationX
                y += v.top + v.translationY
                v = v.parent as? View ?: break
            }
            bg.setBounds(0, 0, v.width, v.height)
            canvas.save()
            canvas.translate(-x, -y)
            bg.draw(canvas)
            canvas.restore()
        }
    }
}
